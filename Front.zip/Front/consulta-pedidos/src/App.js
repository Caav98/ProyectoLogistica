// src/App.js
import React from 'react';
import PedidoConsulta from './PedidoConsulta';

function App() {
  return (
    <div className="App">
      <PedidoConsulta />
    </div>
  );
}

export default App;